<?php return array (
  'add-work' => 'App\\Http\\Livewire\\AddWork',
  'add-worker' => 'App\\Http\\Livewire\\AddWorker',
  'calculate' => 'App\\Http\\Livewire\\Calculate',
  'calculate-all' => 'App\\Http\\Livewire\\CalculateAll',
  'prepayment' => 'App\\Http\\Livewire\\Prepayment',
  'salary' => 'App\\Http\\Livewire\\Salary',
);