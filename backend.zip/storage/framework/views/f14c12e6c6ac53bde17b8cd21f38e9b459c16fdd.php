<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <link rel="stylesheet" href="<?php echo e(asset("/css/app.css")); ?>">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">




</head>
<body class="antialiased">
    <div class="welcome">
        <img src="<?php echo e(url('geesa-logo.png')); ?>" alt="">
        <a href="<?php echo e(url('/login')); ?>" class="btn-lg btn-primary">ՄՈՒՏՔ ՀԱՄԱԿԱՐԳ</a>
    </div>
</body>
<script>

</script>
</html>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/welcome.blade.php ENDPATH**/ ?>