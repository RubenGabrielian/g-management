<?php $__env->startSection("content"); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('calculate', ['worker' => $worker])->html();
} elseif ($_instance->childHasBeenRendered('qPnwdah')) {
    $componentId = $_instance->getRenderedChildComponentId('qPnwdah');
    $componentTag = $_instance->getRenderedChildComponentTagName('qPnwdah');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qPnwdah');
} else {
    $response = \Livewire\Livewire::mount('calculate', ['worker' => $worker]);
    $html = $response->html();
    $_instance->logRenderedChild('qPnwdah', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/workers/calculate.blade.php ENDPATH**/ ?>