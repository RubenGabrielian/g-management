<?php $__env->startSection("content"); ?>


    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(url('/workers')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
                <div class="card">
                    <div class="card-header">
                        <?php echo e($worker->name . ' ' . $worker->surname); ?> - ին տալ կանխավճար / պարտք
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('prepayment', ['worker' => $worker])->html();
} elseif ($_instance->childHasBeenRendered('k8l2peq')) {
    $componentId = $_instance->getRenderedChildComponentId('k8l2peq');
    $componentTag = $_instance->getRenderedChildComponentTagName('k8l2peq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('k8l2peq');
} else {
    $response = \Livewire\Livewire::mount('prepayment', ['worker' => $worker]);
    $html = $response->html();
    $_instance->logRenderedChild('k8l2peq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/prepayments/index.blade.php ENDPATH**/ ?>