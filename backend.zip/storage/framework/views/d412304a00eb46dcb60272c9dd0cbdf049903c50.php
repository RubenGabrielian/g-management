<div class="container">
    <?php
    if (isset($_GET['date'])) {
        $selectedDate = $_GET['date'];
    }
    ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="<?php echo e(url('workers')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
            <div class="card">
                <div class="card-header">
                    Հաշվել աշխատակցի աշխատավարձը (<?php echo e($worker->name); ?> <?php echo e($worker->surname); ?>)
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="">Ընտրել ամիսը</label>
                        <input wire:model="month" type="month" class="form-control">
                    </div>
                    <div class="btn btn-primary mb-3" wire:click="calc">Հաշվել</div>
                    <?php if(!empty($salary)): ?>
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Ամսաթիվ</th>
                                        <th scope="col">Գումար</th>
                                        <?php if($salary[0]->worker->position_id == 2): ?>
                                            <th scope="col">Աշխատանք</th>
                                        <?php endif; ?>
                                        <th scope="col">Քառակուսի մետր</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($salary)): ?>
                                        <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <th scope="row"><?php echo e($sal->id); ?></th>
                                                <td><?php echo e($sal->day . '-' . $sal->month . '-' . $sal->year); ?></td>
                                                <td>
                                                    <?php if($sal->worker->position_id == 1): ?>
                                                        <?php echo e($sal->worker->default_salary); ?>

                                                    <?php else: ?>
                                                        <?php echo e($sal->qm * $sal->work->qm_price); ?>

                                                    <?php endif; ?>
                                                    ֏
                                                </td>
                                                <?php if($sal->worker->position_id == 2): ?>
                                                    <td>
                                                        <?php echo e($sal->work->name); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <td><?php echo e($sal->qm); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <h4 class="text-right">Ընդհանուր այս ամսվա համար ՝ <strong><?php echo e($total); ?> ֏</strong></h4>
                        <hr>
                        <div class="text-right">
                            <?php if(!empty($prepayments)): ?>
                                <?php $__currentLoopData = $prepayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prepayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php  echo $prepayment->type == "prepayment" ? "Կանխավճար" : "Պարտք" ?> <?php echo e($prepayment->price); ?> ֏</p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <h4 class="alert alert-danger">Հանած պարքերը և
                                կանխավճարները: <?php echo e($grandTotal); ?> ֏</h4>
                            <button class="btn btn-danger" wire:click="takeDept">Թողնել պարտք</button>
                            <button class="btn btn-success" wire:click="print"><span>ՏՊԵԼ</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                     class="bi bi-printer" viewBox="0 0 16 16">
                                    <path d="M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                                    <path
                                        d="M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2H5zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4V3zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2H5zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1z"/>
                                </svg>
                            </button>
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($showPrepayment): ?>
                                <div class="take-debt">
                                    <div class="form-group mt-3">
                                        <label for="">Գումարի որ մասն եք ուզում թողնել պարտք</label>
                                        <input type="number" wire:model="prepayment" class="form-control">
                                    </div>
                                    <div class="form-group mt-3">
                                        <label for="">Որ ամսին եք ուզում վերադարձնել</label>
                                        <input type="month" wire:model="whichMonth" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary" wire:click="addPrepayment">Պահպանել</button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/livewire/calculate.blade.php ENDPATH**/ ?>