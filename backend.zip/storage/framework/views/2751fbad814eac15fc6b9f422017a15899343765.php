<?php $date = date("Y-m"); ?>

<div class="card">
    <div class="card-header">
        Տվյալ ամսվա աշխատավարձների ցուցակ <?php echo e(date("Y-m")); ?>

    </div>
    <div class="card-body">
        <button id="changeDateFromAll" class="btn btn-success mb-2">Փոխել ամսաթիվը</button>
        <input type="month" id="changeDateFromAllInput" wire:model="date" class="form-control" value="<?php echo e(date("Y-m")); ?>">
        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table mt-3">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Անուն Ազգանուն</th>
                        <th scope="col">Գումար</th>
                        <th scope="col">ՔՄ / Օրավարձ</th>
                        <th scope="col">Մանրամասն</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row"><?php echo e($worker->id); ?></th>
                            <td><?php echo e($worker->worker->name . '  ' . $worker->worker->surname); ?></td>
                            <td><?php echo e($worker->month_salary); ?> ֏</td>
                            <td><?php echo e($worker->total_qm); ?> <?php if($worker->worker->position_id == 1): ?> Օր/ <?php echo e($worker->worker->default_salary); ?> ֏ <?php else: ?> ՔՄ․ <?php endif; ?></td>
                            <td><a href="<?php echo e(url("/calculate/".$worker->worker->id.'?date='.$selectedDate)); ?>"
                                   class="btn btn-danger to-details">Մանրամասն</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <h4 class="text-right m-0">Ընդհանուր այս ամսվա համար ՝ <strong><?php echo e($all); ?> ֏</strong></h4>
    </div>
</div>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/livewire/calculate-all.blade.php ENDPATH**/ ?>