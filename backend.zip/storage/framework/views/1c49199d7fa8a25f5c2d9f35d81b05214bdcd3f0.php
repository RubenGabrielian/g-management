

<div class="card add-salary">

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="card-header">Ավելացնել աշխատավարձ</div>
    <div class="card-body">

        <?php if($worker->position_id == '1'): ?>
            <div class="alert alert-danger">Նշեք այն օրերը, երբ աշխատակիցը ներկա է եղել</div>
            <div class="multiple"></div>
            <button class="btn btn-primary save-default-worker-salary">Պահպանել</button>
            <input type="hidden" class="worker_id" value="<?php echo e($worker->id); ?>">
            <div class="status"></div>
        <?php else: ?>
            <div class="form-group">
            <label for="">Ընտրել ամսաթիվը</label>
            <input type="date" wire:model="date" class="form-control">
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="">Քառակուսի մետր</label>
            <input type="number" wire:model="qm" class="form-control">
        </div>
            <div class="form-group">
                <label for="">Ընտրել աշխատանքը</label>
                <select name="" class="form-control" wire:model="work" id="">
                    <option value="">Ընտրել</option>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($work->id); ?>"><?php echo e($work->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <div class="form-group">
            <button class="btn btn-primary" wire:click="submit">Պահպանել</button>
        </div>
    </div>
        <?php endif; ?>

        <div class="card-footer">
        <p>Աշխատակից ՝ <?php echo e($worker->name); ?> <?php echo e($worker->surname); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/livewire/salary.blade.php ENDPATH**/ ?>