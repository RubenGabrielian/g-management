<div class="card-body add-work">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="">Անվանում</label>
        <input type="text" wire:model="name" class="form-control">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="">Քառակուսի մետրի գինը</label>
        <input type="text" wire:model="qm_price" class="form-control">
        <?php $__errorArgs = ['qm_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <button class="btn btn-primary" wire:click="add">Ավելացնել</button>
    </div>
    <div class="status"></div>
    <?php if(!empty($works)): ?>
        <div class="col-lg-12 works">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Անուն</th>
                        <th scope="col">Քառակուսի մետրի գին</th>
                        <th scope="col">Պահպանել</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="work-<?php echo e($work->id); ?>">
                            <th scope="row"><?php echo e($work->id); ?></th>
                            <td><?php echo e($work->name); ?></td>
                            <td><input type="text" value="<?php echo e($work->qm_price); ?>" style="width: 100px;"> ֏</td>
                            <input type="hidden" value="<?php echo e($work->id); ?>" class="work-id">
                            <td>
                                <button class="btn btn-success changeWorkPrice">Պահպանել</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/livewire/add-work.blade.php ENDPATH**/ ?>