<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(url('/home')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
                <div class="card">
                    <div class="card-header">Ավելացնել նոր աշխատանք</div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-work', [])->html();
} elseif ($_instance->childHasBeenRendered('wAePLOA')) {
    $componentId = $_instance->getRenderedChildComponentId('wAePLOA');
    $componentTag = $_instance->getRenderedChildComponentTagName('wAePLOA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wAePLOA');
} else {
    $response = \Livewire\Livewire::mount('add-work', []);
    $html = $response->html();
    $_instance->logRenderedChild('wAePLOA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/works/index.blade.php ENDPATH**/ ?>