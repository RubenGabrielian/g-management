<?php $__env->startSection("content"); ?>
    <?php
        $date = date("Y-m");
    ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="<?php echo e(url('home')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('calculate-all', ['date' => $date])->html();
} elseif ($_instance->childHasBeenRendered('su0uusi')) {
    $componentId = $_instance->getRenderedChildComponentId('su0uusi');
    $componentTag = $_instance->getRenderedChildComponentTagName('su0uusi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('su0uusi');
} else {
    $response = \Livewire\Livewire::mount('calculate-all', ['date' => $date]);
    $html = $response->html();
    $_instance->logRenderedChild('su0uusi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/calculate/all.blade.php ENDPATH**/ ?>