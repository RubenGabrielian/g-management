<div class="container add-worker">
    <a href="<?php echo e(url('home')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
            <div class="card">
                <div class="card-header">Ավելացնել նոր աշխատակից</div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name">Անուն</label>
                        <input type="text" class="form-control" wire:model="name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="name">Ազգանուն</label>
                        <input type="text" class="form-control" wire:model="surname">
                        <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="name" class="d-block">Պաշտոն</label>
                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="btn btn-warning" id="position-<?php echo e($position->id); ?>" wire:click="changePosition(<?php echo e($position->id); ?>)"><?php echo e($position->position); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Ստաբիլ օրական աշխատավարձ (ոչ պարտադիր դաշտ)</label>
                        <input type="number" wire:model="defaultSalary" class="form-control">
                    </div>
                    <div class="form-group">
                        <button wire:loading.attr="disabled" wire:click="add" class="btn btn-primary">Ավելացնել</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/livewire/add-worker.blade.php ENDPATH**/ ?>