<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="col-md-12">
            <a href="<?php echo e(url('workers')); ?>" class="btn mb-3 btn-outline-danger">Հետ</a>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('salary', ['worker' => $worker])->html();
} elseif ($_instance->childHasBeenRendered('T8UCpEv')) {
    $componentId = $_instance->getRenderedChildComponentId('T8UCpEv');
    $componentTag = $_instance->getRenderedChildComponentTagName('T8UCpEv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T8UCpEv');
} else {
    $response = \Livewire\Livewire::mount('salary', ['worker' => $worker]);
    $html = $response->html();
    $_instance->logRenderedChild('T8UCpEv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruben.gabrielyan\Desktop\Ruben\g-management\backend\resources\views/workers/addSalary.blade.php ENDPATH**/ ?>