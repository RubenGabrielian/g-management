@extends("layouts.app")
@section('content')

    <livewire:add-worker />

@endsection
