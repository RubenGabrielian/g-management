@extends("layouts.app")
@section("content")

    <livewire:calculate :worker="$worker" />


@endsection
